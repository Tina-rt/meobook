from .meobook import MeoBook, MeoBookError

__version__ = '0.0.7'